//Builds a Robot Object from an id number
var uploadRender = {

  uploadPopup: function () {
    var tile_node = $('<div class="tilepopup" id="uploader"></div>');
		var info_node = $('<div class="tileinfo"></div>');
    var title_node = $('<input name="ititle" class="tiletitle" placeholder="Robot Name"></input>');
    var summary_node = $('<input name="isummary" style="display: inline; width=100px; height:150px;" placeholder="Write Summary here."></input>');
		var form_node = $('<form method="GET" style="display:inline;" action="robot_upload.asp"></form>');
    var uploadbutton_node = $('<button>close</button>');
    var artist_node = $('<input name="iartist" placeholder="Artist"></input>');
    var image_node = $('<input name="iimage" placeholder="Image"></input>');
		var submit_node = $('<input style="disaply:inline;"type=submit value="Submit"></input>');
		form_node.append(title_node, artist_node, image_node, summary_node, submit_node);
    $(uploadbutton_node).click(function () {
       $('#uploader').remove();
    });
		tile_node.append(form_node,uploadbutton_node);
		uploadRender.popupUpload(tile_node);
  },

	//Add a tile (reuires tile node)
  popupUpload: function (node_input) {
		$('body').append($('<div class="browsershadow"></div>'));
    $('body').append(node_input);
  }
};
document.addEventListener('DOMContentLoaded', function () {  
  //tileRender.addTile(tileRender.fillRobotElements(tileRender.testRobot()));
	}
);
