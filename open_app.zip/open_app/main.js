var robotlist;

var store = {
  main: function () {
		$('#b01').click(function () {uploadRender.uploadPopup()});
		//Init option sorters		
		$('#th-1>>div').click(function () {$('#th-1>>div').attr('class','option_off'); this.setAttribute('class','option_on');});
		$('#tr02>>div').click(function () {$('#tr02>>div').attr('class','option_off'); this.setAttribute('class','option_on');});
		//Load Robots from test.json
		var xmlReader = new XMLHttpRequest();
		xmlReader.open("GET", 'test.json');
		xmlReader.onload = function () {
			robotlist = JSON.parse(xmlReader.responseText).robots;
				//Add Default Tiles
				for(var i = 0; i < robotlist.length; i++) {
					tileRender.addTile(tileRender.fillRobotElements(robotlist[i]))
				}
				//Add Default Thumbs	
				for(var j = 0; j < 5; j++) {
					thumbRender.addThumb(thumbRender.fillthumbElements(robotlist[j]),'tr01')
				}
			}
		xmlReader.send();
	},
};
$().ready(function () {
  store.main();
});
